#' ZetaDashboard
#'
#' A package for Hemskoep POS data for ZetaDisplaz
#'
#' @section Foo functions:
#' The foo functions ...
#'
#' @section TO-DOS:
#' \itemize{
#' \item improve documentation
#' \item write this package further
#'  }
#'
#' @docType package
#' @name ZetaDashboard
#' @importFrom magrittr `%>%`
NULL
#> NULL
