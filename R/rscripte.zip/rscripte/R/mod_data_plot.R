#' Barplot of sales
#'
#' Either in fractions or counts
#'
#' @description A shiny Module.
#'
#' @param id,input,output,session Internal parameters for {shiny}.
#'
#' @noRd
#'
#' @importFrom shiny NS tagList
mod_data_plot_ou <- function(id) {
  ns <- shiny::NS(id)
  tagList(
    h3("Sales per week"),
    plotly::plotlyOutput(ns("data_plot")),
    mod_break("small")
  )
}
#' plot_benchmark Server Functions
#'
#' @noRd
mod_plot_data_srv <- function(id, data_subset) {
  stopifnot(shiny::is.reactive(data_subset))
  shiny::moduleServer(id, function(input, output, session) {
    # ns <- session$ns
    output$data_plot <- plotly::renderPlotly({
      # if (is.null(data_subset())) {
      #   plot_out <- plot_fail()
      #   return(plot_out)
      # } else {
      plot_out <- generate_ggplot(data_subset, range_testing = 34)
      # }
      generate_plotly(ggplot_to_use = plot_out)
    })
  })
}
generate_ggplot <- function(data_set, range_testing) {
  stopifnot(shiny::is.reactive(data_set))
  var_dep_taken <- names(data_set())[grepl("TOTAL", names(data_set()))]
  data_ggplot <- get_ggplot_data(data_set(),
                                 var_dep = var_dep_taken,
                                 range_testing = range_testing)
  ggplot_out <- ggplot2::ggplot(data_ggplot, ggplot2::aes(fill = `.`)) +
    ggplot2::geom_bar(ggplot2::aes(x = .data$vecka_time,
                                   y = .data[[var_dep_taken]]),
                      stat = "identity")
  ggplot_out <- ggplot_out +
    ggplot2::labs(y = "count", x = "weeks") +
    zeta_theme_02 +
    ggplot2::scale_fill_manual(values = zeta_color_palette_02[c(1, 2)])
  ggplot_out
}
get_ggplot_data <- function(data_set,
                            var_dep,
                            range_testing) {
  tmp_vec <- data_set$vecka - 202200
  data_set$`vecka_time` <- tmp_vec

  tmp_vec <- data_set$`vecka_time` %in% range_testing
  data_set$`.` <- ifelse(tmp_vec, "testing", "control")

  var_sel <- c(var_dep, "vecka_time", ".")
  data_set %>% dplyr::select(tidyselect::all_of(var_sel))
}
generate_plotly <- function(ggplot_to_use) {
 plotly::ggplotly(ggplot_to_use)
  # plot_out <- plotly::ggplotly(ggplot_to_use)
  # %>%
  #   plotly::layout(legend = list(x = 100,
  #                                y = 0.9,
  #                                title = list(text = "Bereich")),
  #                  annotations = list(text = paste0("Referenzwert: ",
  #                                                   y_coord_ref_val),
  #                                     x = x_coord_ref_val,
  #                                     y = y_coord_ref_val,
  #                                     showarrow = TRUE,
  #                                     xref = "x",
  #                                     yref = "y",
  #                                     axref = "x",
  #                                     ayref = "y",
  #                                     arrowhead = 2,
  #                                     arrowsize = 1.5,
  #                                     ax = ax_ref_text,
  #                                     ay = ay_ref_text))
}
