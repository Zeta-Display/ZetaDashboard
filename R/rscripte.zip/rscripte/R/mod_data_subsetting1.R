mod_data_subset1_main_panel_ui <- function(id) {
  ns <- shiny::NS(id)
  tagList(shiny.semantic::selectInput(ns("sel_butik"),
                                      "Butik:",
                                      choices = list_butik),
          mod_break("small"),
          shiny.semantic::selectInput(ns("sel_ref_unit"),
                                      "Type:",
                                      choices = list_ref_unit),
          mod_break("small"),
          shiny.semantic::selectInput(
            ns("yscale"),
            "Unit:",
            choices = list(count = "cnt", fraction = "frac"),
            selected = "frac")
          # multiple_radio(
          #   ns("yscale"),
          #   "Unit:",
          #   choices = c("count", "fraction"),
          #   choices_value = c("cnt", "frac"),
          #   selected = "frac",
          #   position = "inline"
          # )
  )
}
mod_data_subset1_srv <- function(id) {
  # stopifnot(is.reactive(butik) && is.reactive(ref_unit))
  moduleServer(id, function(input, output, session) {
    reactive({
      tmp_id <- intersect(grep(input$sel_butik, list.files("data/")),
                          grep(input$sel_ref_unit, list.files("data/")))
      if (length(tmp_id) != 1) {
        stop("Subsetting list of data is not unique!")
      } else {
        tmp_id
      }
      data_out <- data_list[[tmp_id]]
      data_out
    })
  }
  )
}
