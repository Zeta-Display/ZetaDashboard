mod_data_subset2_srv <- function(id,
                                 data_subset,
                                 test_week,
                                 num_weeks_cntrl) {
  stopifnot(shiny::is.reactive(data_subset))
  stopifnot(shiny::is.reactive(test_week))
  stopifnot(shiny::is.reactive(num_weeks_cntrl))
  reactive({
    range_weeks <- c(test_week(),
                     seq(from = 33, to = 33 - num_weeks_cntrl() + 1))
    range_weeks <- paste0("2022", range_weeks)
    range_weeks <- as.numeric(range_weeks)
    data_subset() %>% dplyr::filter(.data$vecka %in% range_weeks)
  })
}
mod_data_info_filters_srv <- function(id,
                                      testing_weeks = 34,
                                      num_weeks_cntrl) {
  stopifnot(is.reactive(num_weeks_cntrl))
  shiny::moduleServer(id, function(input, output, session) {
      list(ref_unit = reactive({input$sel_ref_unit}),
           testing_weeks = testing_weeks,
           num_weeks_cntrl = num_weeks_cntrl)
  })
}
