mod_data_subset3_srv <- function(id, data_subset) {
  shiny::moduleServer(id, function(input, output, session) {
    shiny::reactive({
      if (input[["yscale"]] == "cnt") {
        data_subset() %>% dplyr::select(-dplyr::contains("frac"))
        # data_subset()
      } else if (input[["yscale"]] == "frac") {
        data_subset() %>%
          dplyr::select(-dplyr::contains("count")) %>%
          dplyr::mutate_at(dplyr::vars(dplyr::contains("frac")), round, 2)
      }
    })
  })
}
