#' The application server-side
#'
#' @param input,output,session Internal parameters for {shiny}.
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function(input, output, session) {
  # Your application server logic
  dates_taken <- mod_weeks_get_dates_srv("control_testing_weeks")
  mod_weeks_out_dates_srv("control_testing_weeks",
                          dates_taken$start,
                          dates_taken$end,
                          dates_taken$num_weeks)

  data_subset1 <- mod_data_subset1_srv("data_subset1")
  data_subset2 <- mod_data_subset2_srv("data_subset1",
                                       data_subset1,
                                       test_week = dates_taken$test_week,
                                       num_weeks_cntrl = dates_taken$num_weeks)
  data_subset1_info <- mod_data_info_filters_srv("data_subset1",
                                                 testing_weeks = dates_taken$test_week,
                                                 num_weeks_cntrl = dates_taken$num_weeks)
  data_subset3 <- mod_data_subset3_srv("data_subset1",
                                       data_subset2)
  output$table <- reactable::renderReactable({
    reactable::reactable(data_subset3())
  })

  mod_plot_data_srv("plot1", data_subset3)

  htest_out <- mod_hypothesis_testing_srv(id = "hypothesis_testing",
                                          data_subset2,
                                          data_subset1_info$ref_unit,
                                          data_subset1_info$testing_weeks,
                                          data_subset1_info$num_weeks_cntrl)
  mod_hypothesis_testing_write_ou_srv(id = "hypothesis_testing",
                                      htest_out)
  # output$Htest <- shiny::renderPrint(test_out())
}
